import Navbar from './components/Navbar';

import ProductCard from '../components/ProductCard';

function ProductList({ products }) {  //recibe una lista de productos como props
  return (
    <>
      <Navbar />
      <div className="container">
        <div className="row">
          {products.map(product => ( //itera sobre la lista de productos y renderiza un ProductCard para cada uno
            <div className="col-md-3" key={product.id}> 
              <ProductCard {...product} /> {/*pasa todas las propiedades del producto como props al componente ProductCard*/}
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

export default ProductList;
